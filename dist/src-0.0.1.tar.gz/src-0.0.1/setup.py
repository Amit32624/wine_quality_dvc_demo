from setuptools import setup,find_packages

setup(
    name ="src",
    version="0.0.1",
    description="It's is a wine q package",
    author="Amit S",
    packages=find_packages(),
    license ="MIT"

)

